# This program is an Employee Management Tool, to facilitate a number of core business functions.
# Create an empty list.
employees = []


# Read in the file containing the employee details and store the file in the empty list within the Program.
def open_file():
    f = open("employee_file.txt", "r")  # Open employee file as read only.
    for row in f.readlines():  # Read each line in the file.
        employees.append(row.rstrip('\n'))  # Put each record on a new line.
    f.close()  # Close the file.
    return employees  # Return the list now with file contents.


# Creating main menu. The main function.
def main():
    menu = ''

    # While loop. While the menu choice entered is not 9, display the menu choices and return to the
    # main menu each time. This while loop repeats after each choice until the user selects 9 to quit the program.
    while menu != '9':
        display_menu()
        menu = input("\nEnter your choice:	")  # Get the user's choice.

        # This is command (1) Print out a summary statement detailing the number of records1

        # successfully read into your program. If menu = 1 run choice 1.
        while menu != '':
            if menu == '1':
                choice_1()

            # This is command (2) Print out a list of employees with their respective details.
            # Elif menu = 2 run choice 2.

            elif menu == '2':
                choice_2()

            # This is command (3) Print out a report detailing the total salary bill.
            # Elif menu = 3 run choice 3.

            elif menu == '3':
                choice_3()

            # This is command (4) Print a report detailing the average salary bill based on the number of employees.
            # Elif menu = 4 run choice 4.

            elif menu == '4':
                choice_4()

            # This is command (5) Add a new employee to the current list.
            # Elif menu = 5 run choice 5.

            elif menu == '5':
                choice_5()

            # This is command (6) Print a report detailing the number of employees grouped by each position type.
            # Elif menu = 6 run choice 6.

            elif menu == '6':
                choice_6()

            # This is command (7) Query the list by providing a salary threshold above which employees are returned.
            # Elif menu = 7 run choice 7.

            elif menu == '7':
                choice_7()

            # This is command (8) Delete an employee from the current list.
            # Elif menu = 8 run choice 8.

            elif menu == '8':
                choice_8()

            # This is command (9). Quit the program. If the menu choice is 9 run choice 9,
            # If anything other than choice one to nine is entered print an error statement.
            elif menu == '9':
                print("Thank you and goodbye!")
                break

            else:
                print('Error! Please press return and select a choice from one to nine.')

            menu = input("\n Press return to redisplay menu")  # Return to main menu.


# Display main menu
def display_menu():
    print("""

***-MENU-***

Enter the corresponding number to...

1) Print out a summary statement detailing the number of records read into the program.
2) Print out a list of employees and their respective details.
3) Print a report detailing the total salary bill.
4) Print a report detailing the average salary bill based on the numbers of employees.
5) Add a new employee to the current list.
6) Print a report detailing the number of employees grouped by each position type.
7) Query the list by providing a salary threshold above which employees are returned.
8) Delete an employee from the current list
9) Exit the program.""")


# 1. Print out a summary statement detailing the number of records
# successfully read into your program.
def choice_1():
    num_of_emp = len(employees)  # Counts the number of lines in the list to display how many employees there are.
    print(" ******SUMMARY STATEMENT*****\n"
          "The number of employees is", num_of_emp)  # Prints the number of lines/number_of_employees.


# 2. Print out a list of employees with their respective details.
def choice_2():
    print("Employee details:")
    for emp in employees:  # The for statement counts each block of statements(list).
        print(emp)  # Until it reaches the last value and will print the list with all the values.


# 3. Print out a report detailing the total salary bill.
def choice_3():
    salary_total = 0  # Initialize the variable with value zero.

    for salary_paid in employees:
        salary_no = float(salary_paid.strip('\n').split(',')[4])  # Find the fourth item in the list(salary).
        salary_total += salary_no  # Add each item together(salary).

    print('The total salary bill is £',
          format(salary_total, ',.2f'), sep='')  # Print the total salary to 2 decimal places.


# 4. Print a report detailing the average salary bill based on the number of employees.
# noinspection PyUnboundLocalVariable
def choice_4():
    salary_total = 0  # Initialize the variable with value zero.
    no_line = 0  # Initialize the variable with value zero.

    for salary_paid in employees:
        salary_no = float(salary_paid.strip('\n').split(',')[4])  # Find the fourth item in the list(salary).
        salary_total += salary_no  # Add each item together(salary).
        no_line += 1  # Add each line together to get the total number of lines.
        salary_avg = salary_total / no_line  # To get average divide the total salary by the total number of employees.

    print('The average salary bill based on the number of employees is £',
          format(salary_avg, '.2f'), sep='')  # Print the average salary to 2 decimal places.


# 5. Add a new employee to the current list.
def choice_5():
    emp_no = input("Enter new employee number: ")  # Get user input for each employee detail.
    emp_name = input("Enter new employee name: ")
    emp_age = input("Enter new employee age: ")
    emp_position = input("Enter new employee position: ")
    emp_salary = input("Enter new employee salary: ")
    emp_years_emp = input("Enter new employee years employed: ")
    # Append the list 'employees' and add each detail separated by commas to the appropriate item position in the list.
    employees.append(
        emp_no + ", " + emp_name + ", " + emp_age + ", " + emp_position + ", " + emp_salary + ", " + emp_years_emp)

    print(" \n To see new employee in current list select choice 2 from the main menu.")


# 6. Print a report detailing the number of employees grouped by each position type.
def choice_6():
    print("Position/ Number of employees:")
    # Initialize each variable with value zero.
    analyst_count = 0
    developer_count = 0
    devops_count = 0
    tester_count = 0
    # For the third item in the list if it equals the specified name add one to get the
    # total employees for that position.
    for employee in employees:
        position = employee.rstrip().split(', ')[3]
        if position == 'Analyst':
            analyst_count += 1
        elif position == 'Developer':
            developer_count += 1
        elif position == 'DevOps':
            devops_count += 1
        elif position == 'Tester':
            tester_count += 1
    # Print total employees under each position.
    print("Analyst:", analyst_count)
    print("Developer:", developer_count)
    print("DevOps:", devops_count)
    print("Tester:", tester_count)


# 7. Query the list by providing a salary threshold above which employees are returned.
def choice_7():
    salary_threshold = float(
        input("Enter the salary threshold of your choice:"))  # Allow user to enter salary threshold.
    # Attempt at processing more than once.
    # again = 'y' or 'Y'
    print("All employees above selected salary threshold: \n")

    for salary_paid in employees:

        salary_no: float = float(salary_paid.rstrip('\n').split(',')[4])  # Find the fourth item in the list(salary).

        # Attempt at processing more than once.
        # while again == 'y' or again == 'Y':
        # salary_thres = float(input("Enter the salary threshold of your choice:"))

        # If salary less than 19000 or more than 53000 display error message and ask for threshold within the given amounts.
        while salary_threshold < 19000 or salary_threshold > 53000:
            print('Error: No employees available')
            salary_threshold = float(input("Please enter a salary threshold above 18000 or below 53000:"))
        # If the employee salary is greater than the salary threshold given, display employee's details.
        if salary_threshold < salary_no:
            print(salary_paid.rstrip('\n'))


# Attempt at processing more than once.
# again = input('Do you want to enter another threshold? '

# '(Enter y for yes): ')

# 8. Delete an employee from the current list
def choice_8():
    print('Here are the employees in the current list:')
    # Print the current list to allow the user to select an employee to delete.
    for emp in employees:
        print(emp)

    # Allow user to select and paste employee into menu choice to delete employee from the list
    # and check that employee has been deleted by selecting 2 and displaying the current list updated.
    item = input("\nCopy an employee's details of your choice and paste here to delete employee of your choice:")
    print(" \n To see that the employee has been deleted from the current list select choice 2 from the main menu:")
    employees.remove(item)  # Remove selected employee from the list.


# 9. Quit the program
def choice_9():
    f = open("employee_file.txt", "r")
    f.close()  # Close the file.
    print("You have quit the program, \nThank you and goodbye!")


# Call the functions for reading the file and the main menu.
open_file()
main()
